zdanie=input("Podaj jakieś zdanie: ")

ile_a= zdanie.count("a")
ile_A=zdanie.count("A")
print(ile_a+ile_A)