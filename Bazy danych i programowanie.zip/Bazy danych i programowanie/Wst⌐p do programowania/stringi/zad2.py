zdanie=input("Podaj zdanie : ")
o=zdanie[::-1]
print(o)