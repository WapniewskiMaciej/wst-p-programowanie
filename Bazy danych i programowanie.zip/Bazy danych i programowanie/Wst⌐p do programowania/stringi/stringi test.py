# napis ="hello"
# print(napis+" "+napis)
# print(napis*5)
#
# imie= input("Podaj imie: ")
#
# print(napis, imie)
from fontTools.cffLib import privateDictOperators

a="*"

print(a*20)
print(a*20)
print(a*20)
print(a*20)
print(a*10)
print(a," "*6,a)
print(a," "*6,a)
print(a," "*6,a)
print(a*10)

print("trójką prostokątny")

print("*\n**\n***\n****")
print("INDEX")

tekst="Python"
print("Element 1 (ineks 0): ",tekst[0])
print("Element 2 (ineks 1): ",tekst[1])
print("Element 3 (ineks 2): ",tekst[2])
print("Element 4 (ineks 3): ",tekst[3])
print("Element 5 (ineks 4): ",tekst[4])
print("Element 6 (ineks 5): ",tekst[5])

print("Ostatni Element tekstu: ",tekst[-1])
print("Przedostatni Elemetn tekstu: ",tekst[-2])

print("Trzy pierwsze elementy tekstu: ",tekst[0:3])
print("Reszta tekstu: ",tekst[3:])

print(" "*10)
print("METODY")

napis1="HelLo wOrlD"
up=napis1.upper()
low=napis1.lower()
cap=napis1.capitalize()
tit=napis1.title()

print(f"Upper: {up} \nLower: {low}\nCapitalize: {cap}\nTitle: {tit}")

napis2="ile jest banana a ile pomidorów"
cou=napis2.count("ile")
print(f"Liczba ile w tekscie: {cou}")

zmiana=napis2.replace("o","X")
print(zmiana)

tekst="Znajdz olej w tekscie"
szukaj=tekst.find("olej")
print(f"Index: {szukaj}")

lista=["kokos","jajko","olej"]
print(lista)
zdanie=(", ").join(lista)
print(zdanie)