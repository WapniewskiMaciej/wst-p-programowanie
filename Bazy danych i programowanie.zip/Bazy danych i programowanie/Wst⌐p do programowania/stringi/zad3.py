zdanie=input("Podaj zdanie: ")

a=zdanie.replace(" ","_")
b=a.upper()
print(b)