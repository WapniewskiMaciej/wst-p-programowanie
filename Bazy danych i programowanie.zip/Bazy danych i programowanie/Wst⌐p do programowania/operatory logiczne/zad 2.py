liczba=int(input("Podaj liczbę: "))

if liczba%2==0 and liczba >=0:
    print("Liczba jest dodatnia i parzysta")
else:
    print("Liczba nie spełnia warunków")