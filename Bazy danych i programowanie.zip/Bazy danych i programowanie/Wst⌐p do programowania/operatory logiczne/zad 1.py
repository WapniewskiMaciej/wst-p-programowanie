wzrost=eval(input("Podaj wzrost: "))
waga=eval(input("Podaj wagę: "))
w=wzrost/100
bmi = waga/(w**2)
if bmi <= 18.5:
    print("Masz niedowagę")
elif bmi >=18.6 and bmi <=24.9:
    print("Waga prawidłowa")
elif bmi >=25 and bmi <=29.9:
    print("Masz nadwagę")
elif bmi >=30:
    print("Jesteś otyły")
