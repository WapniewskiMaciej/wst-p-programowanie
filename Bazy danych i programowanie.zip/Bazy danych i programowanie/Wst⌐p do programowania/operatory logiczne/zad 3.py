a=8.2
b=5.3
c=2.4

if a>b>c:
    print('wieksza',a,'mniejsza',c)
elif a>c>b:
    print('wieksza',a,'mniejsza',b)
elif b>c>a:
    print('wieksza',b,'mniejsza',a)
elif b>a>c:
    print('wieksza',b,'mniejsza',c)
elif c>a>b:
    print('wieksza',c,'mniejsza',b)
elif c>b>a:
    print('wieksza',c,'mniejsza',a)