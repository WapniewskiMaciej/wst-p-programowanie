# a=10
# b=4
# print(a==b)
# print(a != b)
# print( a >b)
# print(a <b)
# print(a>=b)
# print(a<=b)

# print("negacja")
# print(not True)
# print(not False)
#
# print("alternatywa")
# print(True and True)
# print(True and False)
# print(False and False)
# print(False and True)
#
# print("koniuncja")
# print(True or True)
# print(True or False)
# print(False or False)
# print(False or True)

# punkty=100
#
# if punkty >=80 and punkty <=100:
#     print("Ocena 5")
# else:
#     print("Ocena mniejsza niż 5")
#
# czas_min=60
#
# if punkty >90 or czas_min <70:
#     print("zdany egzamin")
# else:
#     print("oblany egzamin")
#
# temperatura=eval(input("Podaj temperaturę w celcjuszach: "))
# fahre=9/5*temperatura+32
#
# if fahre < 32:
#     print("Temperatura zamarzania wody")
# elif fahre >212:
#     print("Temperatura wrzenia wody")
# else:
#     print("Temperatura normalna")


# rok=eval(input("wprowadz rok do sprawdzenia: "))
#
# if rok % 100 == 0 and rok % 400 == 0:
#     print("Rok przestępny")
# elif rok % 100 == 0 and rok % 400 !=0:
#     print("Nie jest to rok przestępny")
# elif rok % 4 ==0:
#     print("Rok przestępny")
# else:
#     print("Rok nie jest przestępny")

# from random import  randint
#
# zgadnij = randint(1,10)
#
# liczba=eval(input("Podaj liczbę: "))
#
# if liczba==zgadnij:
#     print("Zgadłeś liczbę")
#
# else:
#     print('Nie zgadłeś liczby', zgadnij)