from operator import truediv

print("--FOR--")
numbers=[1,2,3,4,5]
for number in numbers:
    print(number)
print("--------------")
for i in range(10):
    print(i)
print("--------------")
for i in range (2,10,2):

    print(i)
print("--------------")
for num in range(10):
    if num == 5:
        break
    print(num)
print("--------------")
for num in range(10):
    if num == 5:
        continue
    print(num)
print("--WHILE--")
i=1
while i<=5:
    print(i)
    i+=1
print("--------------")
# while True:
#     print(i)
#     if i==5:
#         break
#     i+=1
print("--------------")
# u=0
# while u<5:
#     u +1
#     if u ==3:
#         continue
#     print(u)
print("--------------")
print("--------------")
print("--------------")
