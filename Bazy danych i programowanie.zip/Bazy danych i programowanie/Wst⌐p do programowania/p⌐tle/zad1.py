print("zad1")
for i in range(1,11):
    print(i)
print("zad2")
a=0
for b in range(1,101):
    a+=b
print(a)
print("zad3")
owoce=["banan","malina","melon","kiwi","ananas"]

for owoc in owoce:
    print(owoc)

print("zad4")

slowo=input("Podaj slowo: ")
for lit in slowo:
    print(lit)
print("zad5")

for k in range(1,11):
    print(k*k)

print("zad6")
liczba=1
zgaduj=0
while zgaduj != liczba:
    zgaduj=eval(input("Podaj liczbe od 1 do 10: "))
    if zgaduj==liczba:
        print("zgadles")

print("zad7")
p=0
while p <=20:
    print(p)
    p+=2

print("zad8")
suma=0
j=2
while j<=100:
    suma+=j
    j+=2
print("Suma parzystych: ",suma)
print("zad9")
tabela=[]
for i in range(5):
    elementy=input("Podaj 5 elementów: ")
    tabela += elementy
print(tabela)
usun=input("Podaj do usuniecia: ")
if usun in tabela:
    tabela.remove(usun)
    print(tabela)
else:
    print("Bład")
print("zad10")
licz=eval(input("Podaj liczbę: "))
while licz > 0:
    licz -= 1
    print(licz)
print("zad11")
l=0
z=eval(input("Podaj liczbę do sumy "))
while z != 0:
    l+=z
    z=eval(input("Podaj liczbę do sumy "))

print(l)