# for i in range(0,10,2):
#     print(i,end=" ")
# print("-------")
# for i in range (10,-1,-2):
#     print(i,end=" ")


# for i in range(1,6+1):
#     print(i)

# liczby=[1,2,3,4,5,67,10,20,30,60]
#
# for liczba in liczby:
#     print(liczba)
#
# tekst="Python"
# for i in tekst:
#     print(i)
#
owoce=["banan","malina","melon","kiwi"]

for owoc in owoce:
    print(owoc)

# for i in range(10):
#     print(i,"----")
#     if i == 5:
#         break
#
#
# for i in range(5):
#     if i == 2:
#         continue
#     print(i)

# liczby=[1,2,3,4,5,67,10,20,30,60]
# dlugosc=len(liczby)
# for i in range(2,dlugosc,2):
#     print(i)


# temper=0
#
# while temper != -1000:
#     temper = eval(input("Podaj temperaturę w celcjuszach: "))
#     print("temper w fahr: " , temper*9/5+32)


# while True:
#     temper = eval(input("Podaj temperaturę w celcjuszach: "))
#     if temper == -1000:
#         print("KONIEC")
#         break
#     print("Twoja temperatura w fahr: ",temper*9/5+32)

