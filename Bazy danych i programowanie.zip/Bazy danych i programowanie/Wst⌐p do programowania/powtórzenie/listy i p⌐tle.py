#1
from pętle.zad1 import licz, liczba

temperatury=[18,23,20,25,17,22]
wynik=[]
for i in temperatury:
    if i>20:
        wynik.append(i)
print(wynik)
print(f"Więcej niż 20 stopni ma {len(wynik)} temperatury")

#2

numery=[104,102,104,107,102,108]

unikalne=[]
for i in numery:
    if i not in unikalne:
        unikalne.append(i)
print(unikalne)

#3
pomiary=[80,74,74,61,65]
wynik=[]

for i in range(1,len(pomiary)):
    roznica=pomiary[i]-pomiary[i-1]
    wynik.append(roznica)
print(wynik)

#4

wynik=[]
while True:
    liczba=int(input("Podaj wynik kolokwium (-1 kończy): "))
    if liczba ==-1:
        break
    elif 0 <=liczba <=20:
        wynik.append(liczba)
    else:
        print("Wynik w przedziale 0-20")
print(wynik)

#5
ceny=[12,8,17,5]
budzet=30
kupione=[]
index=0

while index <len(ceny):
    cena=ceny[index]
    if cena <= budzet:
        kupione.append(cena)
        budzet -=cena
        index+=1
    else:
        break
