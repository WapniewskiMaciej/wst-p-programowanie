#1

n=eval(input("Podaj liczbę: "))

#a
if n==0:
    a=1
else:
    a=0
    temp=n
    while temp>0:
        a+=1
        temp//=10
print(a)
#b
suma=0
temp=n
while temp > 0:
    suma += temp%10
    temp //= 10
print(suma)
#c
temp=n
while temp>=10:
    temp//=10

print(temp)

#2
obrot=0
temp=n
while temp>0:
    cyfra=temp%10
    obrot=obrot*10+cyfra
    temp //=10
print(obrot)

#3

import random

losowa=random.randint(1,100)
a= None

while a!=losowa:
    a= int(input("Podaj liczbe: "))
    if a> losowa:
        print("daj mniejszą")
    elif a< losowa:
        print("Daj większą")
    else:
        print("tafił")