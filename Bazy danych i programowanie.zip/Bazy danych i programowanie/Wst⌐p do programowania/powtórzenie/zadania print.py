#1
print(512-(282/47)*48+5)

#2
# x=eval(input("Podaj liczbe: "))
# for i in range(x):
#     i+=1
#     print(f"{x*i}", end="---" )
# print("\n")

#3
#
# a=float(input("Podaj liczbe po przecinku: "))
# b=float(input("Podaj liczbe po przecinku: "))
#
# print(a*b)

#4
# a=float(input("Podaj wage: "))
# funty=a*0.22
# print(funty*10)

#5

for i in range (11):
    i+=i
print("suma",i)

#6

for i in range (11):
    i=i*i
print("iloczyn",i)

#7
dni=[31,29,30]

dnisum=sum(dni)
print(dnisum)