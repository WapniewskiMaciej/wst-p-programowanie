#1
for i in range(101):
    if i %2 ==0:
        i+=i
print(i)

#2

for i in range(101):
    i+= i*i
print(i)

#3

for i in range(64):
    i=2**i
print(i)

#4

a=eval(input("Podaj a: "))
b=eval(input("Podaj b: "))
suma=0
if a>b:
    suma=0
else:
    for i in range(a,b+1):
        if i%2!=0:
            suma+=i
print(suma)