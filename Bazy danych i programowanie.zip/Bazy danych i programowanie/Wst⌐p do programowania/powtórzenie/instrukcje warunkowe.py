#1
# a=float(input("Podaj liczbe po przecinku: "))
# if a>=0:
#     print(a)
# else:
#     print(-a)

#2
# a=float(input("Podaj liczbe po przecinku: "))
# b=float(input("Podaj liczbe po przecinku: "))
#
# if b !=0:
#     print(a/b)
# else:
#     print("Nie dziel przez 0")

#3
# a=float(input("Podaj liczbe po przecinku: "))
# b=float(input("Podaj liczbe po przecinku: "))
# c=float(input("Podaj liczbe po przecinku: "))
#
# if a>b>c:
#     print('wieksza',a,'mniejsza',c)
# elif a>c>b:
#     print('wieksza',a,'mniejsza',b)
# elif b>c>a:
#     print('wieksza',b,'mniejsza',a)
# elif b>a>c:
#     print('wieksza',b,'mniejsza',c)
# elif c>a>b:
#     print('wieksza',c,'mniejsza',b)
# elif c>b>a:
#     print('wieksza',c,'mniejsza',a)


#4

# bok1=eval(input("Podaj bok trójkąta: "))
# bok2=eval(input("Podaj bok trójkąta: "))
# bok3=eval(input("Podaj bok trójkąta: "))
# if bok1 and bok2 <=0:
#     print("bok mniejszy niz 0")
# else:
#     print((bok1*bok2)/2)
#     print(bok1+bok2+bok3)


