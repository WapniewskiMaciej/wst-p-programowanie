lista=[]

for i in range(10):
    liczba=eval(input(f"Podaj liczbę {i+1}: "))
    lista.append(liczba)
print(lista)
print("Maksymalna:",max(lista),"Minimalna: ",min(lista))