lista=[]

for i in range(10):
    liczba=eval(input(f"Podaj liczbę {i+1}: "))
    lista.append(liczba)
print(lista)
element=eval(input('Podaj elemnet do znalezienia: '))
dlugosc=lista.count(element)
print("ile jest wystąpień tego elementu: ",dlugosc)
usun=eval(input('Podaj index do usunięcia: '))
usuniety=lista.pop(usun)
print("Usunięty index:", usuniety)