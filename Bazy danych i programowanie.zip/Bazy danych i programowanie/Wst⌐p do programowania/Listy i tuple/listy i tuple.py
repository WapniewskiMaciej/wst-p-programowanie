import ow

lista=[1,2,3,'cztery',5.0,[6,7],"osiem"]
print(lista)
print(lista[5])
print(lista[5][1])

lista.append("nowy element")
print("Lsita po dodaniu elementu: ", lista)
lista.insert(0,"**")
print("Na index 0: ",lista)

lista.remove("osiem")
print("bez osiem",lista)

element= lista.pop(0)

print(element)
print("Lista po usunięciu przez pop: ",lista)
print("Ostatni element listy: ", lista[-1])

nowa_lista=[-1,11,230,-70,45,0]
nowa_lista.reverse()
print("Odwrócenie listy: ",nowa_lista)

nowa_lista.sort()
print("Posortowana lista: ",nowa_lista)

owoce=['banan',"kiwi","morela",'malina']
print("Długość listy: ", len(owoce))
print("Pierwsze 2 elementy listy: ",owoce[:2])
owoce[1]="truskawka"
print("Podmiana elementów lsity: ",owoce)
idx=owoce.index("banan")
print("Index danego elementu: ",idx)


tuple1=(1,2,"trzy",4.0,5)
print(tuple1)
print(tuple1[0])
print("Długość tupli: ",len(tuple1))
lista2=list(tuple1)
lista2.append(6)
tuple1= tuple(lista2)
print("Nowy element tupli: ",tuple1)
